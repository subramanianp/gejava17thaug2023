package com.ge.training.generics;

class A{
	private int i;

	public A(int i) {
		super();
		this.i = i;
	}

	@Override
	public String toString() {
		return "A [i=" + i + "]";
	}
	
	
}

public class GenericTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Pair<Integer> p1=new Pair<Integer>(10, 20);
		Pair<String> p2=new Pair<>("hello", "world");
		Pair<A> p3=new Pair<>(new A(20), new A(30));
		
		System.out.println(p1);
		System.out.println(p2);
		System.out.println(p3);
		

	}

}
