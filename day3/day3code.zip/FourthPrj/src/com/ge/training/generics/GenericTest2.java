package com.ge.training.generics;

class Sample{
	static <T> void display(T element)
	{
		System.out.println(element.getClass().getName()+"----"+element);
	}
}

public class GenericTest2 {
public static void main(String[] args) {
	A a=new A(10);
	String b="hello";
	int c=12;
	
	Sample.display(a);
	Sample.display(b);
	Sample.display(c);
}
}
