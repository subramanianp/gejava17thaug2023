package com.ge.training.arrays;

public class ArrayTest2 {
public static void main(String[] args) {
	int[][] a= {//2 dimensional array is a collection of one dimensional arrays
			{3,2,10},
			{12,4},
			{3,5,1,20}
	};
	for(int i=0;i<a.length;i++) {
		System.out.println();
		for(int j=0;j<a[i].length;j++) {
			System.out.print(a[i][j]+"\t");
		}
	}
	System.out.println();
	System.out.println("using enhanced for loop");
	for(int[] x:a) {
		System.out.println();
		for(int y:x) {
			System.out.print(y+"\t");
		}
	}
}
}
