package com.ge.training.arrays;
class A{
	private int i;

	public A(int i) {
		super();
		this.i = i;
	}

	@Override
	public String toString() {
		return "A [i=" + i + "]";
	}
	
	
}

public class ArrayTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr1=new int[3];
		arr1[0]=12;
		arr1[1]=3;
		arr1[2]=30;
		for(int i=0;i<arr1.length;i++) {
			System.out.println(arr1[i]);
		}
		System.out.println("using enhanced for loop");
		for(int x:arr1) {
			System.out.println(x);
		}
		A[] arr2=new A[4];
		for(int i=0;i<arr2.length;i++) {
			arr2[i]=new A(10+i);
		}
		for(A a:arr2) {
			System.out.println(a);
		}

	}

}
