package com.ge.training.innerclasses;

class R{
	void method1()
	{
		System.out.println("method1 of R");
	}
}

class A{
	void test() {
		System.out.println("method of A");
	}
	class B extends R{ //non static inner class of A
		void test() {
			System.out.println("method of B");
			method1();
			A.this.test();
		}
	}
}
public class NonStaticInnerTest {
public static void main(String[] args) {
	A a=new A();
	A.B b=a.new B();
	a.test();
	b.test();
}
}
