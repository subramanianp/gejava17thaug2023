package com.ge.training.innerclasses;

class X{
	void sample()
	{
		int p=20;
		class Y{
			int i=10;
			void print()
			{
				System.out.println(p);
			}
		}
		Y y1=new Y();
		System.out.println(y1.i);
		y1.print();
	}
}

public class LocalClassTest {
public static void main(String[] args) {
	X x1=new X();
	x1.sample();
}
}
