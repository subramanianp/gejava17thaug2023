package com.ge.training.innerclasses;

class C{
	static int i=10;
	static class D{
		void test()
		{
			System.out.println("method of D");
			System.out.println(i);
		}
	}
}

public class StaticInnerTest {
public static void main(String[] args) {
	C.D d=new C.D();
	d.test();
}
}
