package com.ge.training.innerclasses;

abstract class F{
	abstract String getMessage(String name);
	void printMessage(String name)
	{
		System.out.println("Message:"+getMessage(name));
	}
}

public class AnonymousClassTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			F f=new F() {//starting of subclass of F
					/*
							Extending the class F
							overriding getMessage() method
							Creating the object for the subclass of F
					*/
				@Override
				String getMessage(String name) {
					// TODO Auto-generated method stub
					return "Welcome "+name;
				}
				
			};//ending of subclass of F
			f.printMessage("Arvind");
			
	}

}
