package com.ge.training.oops;

class A{
	final int k;
	
	  A(int k) {
		  this.k=k; 
	  }
	 
}

class B{
	private int a;
	private double b;
	private boolean c;
	private char d;
	private String e;
	@Override
	public String toString() {
		return "B [a=" + a + ", b=" + b + ", c=" + c + ", d=" + d + ", e=" + e + "]";
	}
	
}

public class FinalTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final int a;
		a=10;
		//a=11;
		B b1=new B();
		System.out.println(b1);

	}

}
