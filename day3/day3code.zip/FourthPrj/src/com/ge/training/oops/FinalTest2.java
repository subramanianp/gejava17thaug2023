package com.ge.training.oops;
class Sample{
	public static final int DISCOUNT_RATE=12;
}

public class FinalTest2 {
public static void main(String[] args) {
	System.out.println(Sample.DISCOUNT_RATE);
}
}
