package com.ge.training.interfaces;

interface Flyer{
	void fly();
}
interface Feedable{
	void eat();
}
interface A{
	void method1();
	default void method2() {
		System.out.println("non static method method2");
	}
	static void method3() {
		System.out.println("static method method3");
	}
}
class B implements A{

	@Override
	public void method1() {
		// TODO Auto-generated method stub
		System.out.println("method1");
	}
	
}
class Aeroplane implements Flyer{

	@Override
	public void fly() {
		// TODO Auto-generated method stub
		System.out.println("Aeroplane Flying");
	}
	
}
class Bird implements Flyer,Feedable{

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("Bird eating");
	}

	@Override
	public void fly() {
		// TODO Auto-generated method stub
		System.out.println("Bird flying");
	}
	
}
interface I{
	String ANIMAL_TYPE="HERBIVOROUS";
}

public class InterfaceTest {
public static void main(String[] args) {
	Flyer f=new Bird();
	f.fly();
	Feedable feedable=(Feedable)f;
	feedable.eat();
	
	System.out.println(f instanceof Flyer);
	System.out.println(f instanceof Feedable);
	Flyer f1=new Aeroplane();
	System.out.println(f1 instanceof Flyer);
	System.out.println(f1 instanceof Feedable);
	A a=new B();
	a.method1();
	a.method2();
	A.method3();
	System.out.println(I.ANIMAL_TYPE);
}
}
