package com.ge.training.exceptions;

public class ExceptionTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=10;
		System.out.println("before dividing ");
		try {
		System.out.println(x/0);
		}catch(ArithmeticException e) {
			System.out.println("Divide by zero error");
			return;
		}finally {
			System.out.println("within finally");
		}
		System.out.println("after dividing by zero");
	}

}
