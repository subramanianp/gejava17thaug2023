package com.ge.training.exceptions;

public class ExceptionTest2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		try {
			int x=Integer.parseInt(args[0]);
			int y=Integer.parseInt(args[1]);
			System.out.println(x/y);
		}catch(ArithmeticException e) {
			System.out.println("Divide by zero error");
			
		}catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("insufficient arguments");
		}catch(NumberFormatException e) {
			System.out.println("number not in proper format");
		}
		finally {
			System.out.println("within finally");
		}
		System.out.println("after dividing by zero");
	}

}
