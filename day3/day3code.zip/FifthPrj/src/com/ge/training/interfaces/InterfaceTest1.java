package com.ge.training.interfaces;

interface A{
	void method1();
	/*
	 * default void method2() {
	 * 
	 * } static void method3() {
	 * 
	 * }
	 */
}

public class InterfaceTest1 {

}
