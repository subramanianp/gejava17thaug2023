package com.ge.training.exceptions;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class ThrowsTest {
public static void main(String[] args) {
	
	System.out.println("Going to wait for 5 secs");
	try {
		delay(5000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	System.out.println("After 5 secs");
	try {
		createFileAndDelay("c:/test/next.txt");
	} catch (FileNotFoundException | InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}

static void delay(long millisecs) throws InterruptedException
{
	
	Thread.sleep(millisecs);
	
}

static void createFileAndDelay(String fileName) throws FileNotFoundException, InterruptedException
{
	FileOutputStream fout=new FileOutputStream(fileName);
	Thread.sleep(1000);
}
}
