package com.ge.training.exceptions;

public class MyResource  implements AutoCloseable{
	private int i;

	public MyResource(int i) {
		super();
		this.i = i;
	}

	@Override
	public void close() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("closing myresource");
		i=0;
	}
	
	public void test()
	{
		System.out.println("testing myresource with value: "+i);
	}

}
