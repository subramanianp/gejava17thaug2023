package com.ge.training.exceptions;

public class TryWithResourcesTest1 {
	public static void main(String[] args) {
		try(MyResource resource=new MyResource(10)){
			System.out.println("using resource");
			resource.test();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("completing main method");
	}

}
