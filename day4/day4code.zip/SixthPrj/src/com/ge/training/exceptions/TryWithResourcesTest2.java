package com.ge.training.exceptions;

public class TryWithResourcesTest2 {
	public static void main(String[] args) {
		try(MyResource resource1=new MyResource(10);MyResource resource2=new MyResource(15)){
			System.out.println("using resource");
			resource1.test();
			resource2.test();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("completing main method");
	}

}
