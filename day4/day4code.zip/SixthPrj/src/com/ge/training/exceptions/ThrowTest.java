package com.ge.training.exceptions;


class NegativeNumberException extends Exception{

	public NegativeNumberException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}

public class ThrowTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=Integer.parseInt(args[0]);
		try {
			double squareRoot=findSquareRoot(n);
			System.out.println("Square root: "+squareRoot);
		} catch (NegativeNumberException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

	private static double findSquareRoot(int n) throws NegativeNumberException {
		// TODO Auto-generated method stub
		if(n<0) {
			throw new NegativeNumberException("Invalid number "+n);
		}
		return Math.sqrt(n);
	}

}
