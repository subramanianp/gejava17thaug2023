package com.ge.training.collections;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class ListTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> list=new ArrayList<>();
		list.add("apple");
		list.add("orange");
		list.add("pine apple");
		System.out.println(list);
		
		System.out.println("using enhanced for loop");
		for(String s:list) {
			System.out.println(s);
		}
		
		System.out.println("using foreach lambda");
		list.forEach(elt->System.out.println(elt));
		
		System.out.println("using foreach method ref");
		list.forEach(System.out::println);
		Consumer<String> consumer=System.out::println;
		list.forEach(consumer);
		
		consumer=e->System.out.println(e);
		list.forEach(consumer);
		
		List<Object> list1=new ArrayList<>();
		list1.add(11);
		list1.add(21.55);
		list1.add("hello");
		list1.add(11);
		System.out.println(list1);
		
		

	}

}
