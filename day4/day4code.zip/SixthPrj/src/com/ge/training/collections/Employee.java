package com.ge.training.collections;

public class Employee{
	private int id;
	private String name;
	private String designation;
	private double salary;
	public Employee(int id, String name, String designation, double salary) {
		super();
		this.id = id;
		this.name = name;
		this.designation = designation;
		this.salary = salary;
	}
		@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", designation=" + designation + ", salary=" + salary + "]";
	}
		@Override
		public boolean equals(Object obj) {
			// TODO Auto-generated method stub
			
			boolean equals=false;
			Employee e1=(Employee)obj;
			System.out.println("invoking equals of "+id);
			if(id==e1.id&&name.equals(e1.name)&&designation.equals(e1.designation)) {
				equals=true;
			}
			return equals;
		}
		@Override
		public int hashCode() {
			// TODO Auto-generated method stub
			System.out.println("invoking hashCode of "+id);
			return id;
		}
		
		
	
}
