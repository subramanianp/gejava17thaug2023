package com.ge.training.collections;

import java.util.SortedSet;
import java.util.TreeSet;

public class SortedSetTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SortedSet<String> set=new TreeSet<>();
		set.add("mango");
		set.add("grape");
		set.add("mango");
		set.add("apple");
		set.add("mango");
		System.out.println(set);
		
		SortedSet<Integer> set1=new TreeSet<>();
		set1.add(23);
		set1.add(10);
		set1.add(12);
		set1.add(51);
		set1.add(31);
		System.out.println(set1);
		

	}

}
