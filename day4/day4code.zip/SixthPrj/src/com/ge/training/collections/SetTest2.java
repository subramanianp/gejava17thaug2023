package com.ge.training.collections;

import java.util.HashSet;
import java.util.Set;

public class SetTest2 {
public static void main(String[] args) {
	Set<Employee> set=new HashSet<>();
	set.add(new Employee(1001, "Deva", "Developer", 30000));
	set.add(new Employee(1002, "Raghav", "Acccountant", 25000));
	set.add(new Employee(1001, "Deva", "Developer", 30000));
	set.add(new Employee(1005, "Surya", "Architect", 80000));
	set.add(new Employee(1001, "Deva", "Developer", 30000));
	set.add(new Employee(1002, "Raghav", "Acccountant", 25000));
	set.forEach(System.out::println);
}
}
