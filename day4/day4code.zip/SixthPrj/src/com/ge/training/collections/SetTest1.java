package com.ge.training.collections;

import java.util.HashSet;
import java.util.Set;

public class SetTest1 {
public static void main(String[] args) {
	Set<Integer> set1=new HashSet<>();
	set1.add(12);
	set1.add(56);
	set1.add(12);
	set1.add(56);
	set1.add(22);
	System.out.println(set1);
	
}
}
