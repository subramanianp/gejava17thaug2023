package com.ge.training.collections;
interface I{
	void method1();
}
interface J extends I{
	void method2();
}
class X implements J{

	@Override
	public void method1() {
		// TODO Auto-generated method stub
		System.out.println("method1");
	}

	@Override
	public void method2() {
		// TODO Auto-generated method stub
		System.out.println("method2");
	}
	
}

public class InterfaceTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		I i=new X();
		i.method1();
		J j=(J)i;
		j.method2();
	}

}
