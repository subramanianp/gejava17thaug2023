package com.ge.training.functional;

@FunctionalInterface
interface K{
	int calc(int a);
}

public class LambdaTest3 {
public static void main(String[] args) {
	K k=getData();
	System.out.println(k.calc(5));
}

static K getData() {//function returning another function
	System.out.println("within getData");
	return x->x*x;
}
}
