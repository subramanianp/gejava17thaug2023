package com.ge.training.functional;
@FunctionalInterface
interface I1{
	int calculate(int i,int j);
}

@FunctionalInterface
interface I2{
	String displayFormat(int p,int q);
}

public class LambdaTest4 {
public static void main(String[] args) {
		I2 i2=performComputation((a,b)->a*b);
		System.out.println(i2.displayFormat(10, 20));
}


static I2 performComputation(I1 i1)
{
	return (r1,r2)->"Computated value: "+i1.calculate(r1, r2);
}

}
