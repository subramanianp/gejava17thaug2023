package com.ge.training.functional;
interface F{
	void test(String s);
}


class P{
	static void doSomething(String a)
	{
	System.out.println("doing something with "+a);
	}
}

class Q{
	void testing(String k)
	{
		System.out.println("testing with k");
	}
}

public class MethodReference1 {
public static void main(String[] args) {
	F f=P::doSomething;
	f.test("hello, world");
	Q q=new Q();
	f=q::testing;
	f.test("scala");
}
}
