package com.ge.training.functional;

class Employee{
	private int id;
	private String name;
	private String designation;
	private double salary;
	public Employee(int id, String name, String designation, double salary) {
		super();
		this.id = id;
		this.name = name;
		this.designation = designation;
		this.salary = salary;
	}
	public Employee(int id) {
		super();
		this.id = id;
	}
	public Employee(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	public Employee(int id, String name, String designation) {
		super();
		this.id = id;
		this.name = name;
		this.designation = designation;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", designation=" + designation + ", salary=" + salary + "]";
	}
	
}


@FunctionalInterface
interface EmployeeFactory1{
	Employee createEmployee(int id);
}
@FunctionalInterface
interface EmployeeFactory2{
	Employee createEmployee(int id,String name);
}

@FunctionalInterface
interface EmployeeFactory3{
	Employee createEmployee(int id,String name,String designation);
}

@FunctionalInterface
interface EmployeeFactory4{
	Employee createEmployee(int id,String name,String designation,double salary);
}


public class ConstructorReferenceTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeFactory1 factory1=Employee::new;
		EmployeeFactory2 factory2=Employee::new;
		EmployeeFactory3 factory3=Employee::new;
		EmployeeFactory4 factory4=Employee::new;
		
		
		Employee emp1=factory1.createEmployee(1001);
		Employee emp2=factory2.createEmployee(1002,"Surya");
		Employee emp3=factory3.createEmployee(1003,"Ramesh","Accountant");
		Employee emp4=factory4.createEmployee(1004,"Ajay","Developer",60000);
		
		System.out.println(emp1);
		System.out.println(emp2);
		System.out.println(emp3);
		System.out.println(emp4);
		

	}

}
