package com.ge.training.functional;
@FunctionalInterface
interface I{
	String getMessage(String name);
	
}
interface J{
	int calculate(int a,int b);
}

public class LambdaTest1 {
public static void main(String[] args) {
	I i1=n->{
		System.out.println("Within lambda");
		return "Welcome "+n;
	};
	System.out.println(i1.getMessage("Arun"));
	J j1=(x,y)->x+y;
	System.out.println(j1.calculate(10, 8));
	test((a,b)->a*a+b*b,2,3);
}
static void test(J j,int x,int y)
{
	System.out.println(j.calculate(x,y));
}

}
