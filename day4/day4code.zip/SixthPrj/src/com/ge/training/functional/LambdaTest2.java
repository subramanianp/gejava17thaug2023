package com.ge.training.functional;

@FunctionalInterface
interface D{
	String message(String name);
	default void test()
	{
		System.out.println("test method of D");
	}
	default void next() {
		System.out.println("next method of D");
	}
}

public class LambdaTest2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		display(s->"Good morning ", "Arvind");

	}
	
	static void display(D d,String name)
	{
		System.out.println(d.message(name));
		d.test();
		d.next();
	}

}
