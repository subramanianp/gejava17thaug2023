package com.ge.training.collections;

class A{
	private static int counter;
	A()
	{
		counter++;
	}
	public static int getCounter() {
		return counter;
	}
	static {//gets automatically invoked when the class is loaded into memory
		String count=System.getProperty("count");
		counter=Integer.parseInt(count);
	}
	
}

public class StaticBlockTest {
	public static void main(String[] args) {
		A a1=new A();
		A a2=new A();
		A a3=new A();
		System.out.println(A.getCounter());
	}

}
