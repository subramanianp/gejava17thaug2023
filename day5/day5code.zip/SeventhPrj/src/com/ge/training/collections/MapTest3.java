package com.ge.training.collections;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class MapTest3 {
public static void main(String[] args) {
	Properties props=new Properties();
	
	
	try(FileInputStream fin=new FileInputStream("state.properties")){
		props.load(fin);
		System.out.println("Capital of Karnataka: "+props.get("Karnataka"));
		
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
}
