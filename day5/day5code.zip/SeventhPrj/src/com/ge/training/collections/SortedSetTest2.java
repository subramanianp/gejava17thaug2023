package com.ge.training.collections;

import java.util.SortedSet;
import java.util.TreeSet;

public class SortedSetTest2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SortedSet<Customer> set=new TreeSet<>((c1,c2)->c1.getName().compareTo(c2.getName()));
		set.add(new Customer(1011, "Aman", "aman@gmail.com"));
		set.add(new Customer(1001, "Surya", "surya@gmail.com"));
		set.add(new Customer(1005, "Rajiv", "rajiv@gmail.com"));
		set.add(new Customer(1002, "Priya", "priya@gmail.com"));
		set.add(new Customer(1005, "Rajiv", "rajiv@gmail.com"));
		set.add(new Customer(1002, "Priya", "priya@gmail.com"));
		
		System.out.println(set);
		
		

	}

}
