package com.ge.training.collections;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class MapTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<Integer, Customer> map=new HashMap<>();
		map.put(1001, new Customer(1001, "Rajiv", "rajiv@yahoo.com"));
		map.put(1002, new Customer(1002, "Deva", "deva@gmail.com"));
		map.put(1003, new Customer(1003, "Amar", "amar@yahoo.com"));
		
		Customer c=map.get(1002);
		System.out.println(c.getName()+"\t"+c.getEmail());
		
		Set<Integer> set=map.keySet();
		set.forEach(key->System.out.println(key+"\t"+map.get(key)));
		
		map.forEach((key,value)->System.out.println(key+"==>"+value));
	}

}
