package com.ge.training.collections;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class MapTest2 {
public static void main(String[] args) {
	Properties props=new Properties();
	props.put("Karnataka", "Bangalore");
	props.put("Maharashtra", "Mumbai");
	props.put("Tamil Nadu","Chennai");
	
	try(FileOutputStream fout=new FileOutputStream("state.properties")){
		props.store(fout, "---testing properties collection--------");
		
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	System.out.println("properties written to the file");
}
}
