package com.ge.training.collections;

import java.util.Comparator;
import java.util.SortedSet;
import java.util.TreeSet;

class StringComparator implements Comparator<String>{

	@Override
	public int compare(String s1, String s2) {
		// TODO Auto-generated method stub
		return s2.compareTo(s1);
	}
	
}

public class SortedSetTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SortedSet<String> set=new TreeSet<>(new StringComparator());
		set.add("mango");
		set.add("grape");
		set.add("mango");
		set.add("apple");
		set.add("mango");
		System.out.println(set);
		
		SortedSet<Integer> set1=new TreeSet<>((i1,i2)->i2.compareTo(i1));
		set1.add(23);
		set1.add(10);
		set1.add(12);
		set1.add(51);
		set1.add(31);
		System.out.println(set1);
		

	}

}
