package com.ge.training.threads;

class XThread extends Thread{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=1;i<=100;i++) {
			System.out.println("Within XThread "+i);
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
}
public class ThreadTest4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		XThread xt=new XThread();
		xt.start();
		for(int i=1;i<=25;i++) {
			System.out.println("Inside main thread "+i);
		}
		try {
			xt.join(); //main thread goes to blocked state till xt is completed
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("is XThread  alive-->"+xt.isAlive());
		for(int i=26;i<=50;i++) {
			System.out.println("Inside main thread "+i);
		}

	}

}
