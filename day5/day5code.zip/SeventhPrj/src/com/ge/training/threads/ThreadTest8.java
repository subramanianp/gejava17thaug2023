package com.ge.training.threads;

class CThread extends Thread{
	private F f;
	

	public CThread(F f) {
		super();
		this.f = f;
	}


	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		synchronized(f) {
			System.out.println(Thread.currentThread().getName()+" is going to invoke notifyAll() on f");
			f.notifyAll();
			System.out.println(Thread.currentThread().getName()+" after invoking notifyAll() on f");
		}
		
		
	}
	
}

public class ThreadTest8 {
public static void main(String[] args) {
	F f=new F();
	for(int i=1;i<=10;i++) {
		AThread t=new AThread(f);
		t.setName("AThread "+i);
		t.start();
	}
	CThread cThread=new CThread(f);
	cThread.setName("Notifying Thread");
	cThread.start();
}
}
