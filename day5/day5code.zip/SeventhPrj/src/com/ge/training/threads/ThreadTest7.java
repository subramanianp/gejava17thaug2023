package com.ge.training.threads;

class F{
	
}

class AThread extends Thread{
	private F f;
	

	public AThread(F f) {
		super();
		this.f = f;
	}


	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		synchronized(f) {
			System.out.println(Thread.currentThread().getName()+" is going to invoke wait() on f");
			try {
				f.wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(Thread.currentThread().getName()+" got unblocked");
		}
		
		
	}
	
}


class BThread extends Thread{
	private F f;
	

	public BThread(F f) {
		super();
		this.f = f;
	}


	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		synchronized(f) {
			System.out.println(Thread.currentThread().getName()+" is going to invoke notify() on f");
			f.notify();
			System.out.println(Thread.currentThread().getName()+" after invoking notify() on f");
		}
		
		
	}
	
}

public class ThreadTest7 {
public static void main(String[] args) {
	F f=new F();
	AThread aThread=new AThread(f);
	aThread.setName("First Thread");
	BThread bThread=new BThread(f);
	bThread.setName("Second Thread");
	aThread.start();
	bThread.start();
}
}
