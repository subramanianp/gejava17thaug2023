package com.ge.training.threads;

public class ThreadTest3 {
public static void main(String[] args) {
	Thread t1=new Thread(()-> {
		System.out.println("Going to sleep for 5 secs");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			System.out.println("Interrupted while sleeping");
		}
		System.out.println("After waking up");
	});
	t1.start();
	try {
		Thread.sleep(500);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	System.out.println("main thread is going to interrup thread t1");
	t1.interrupt();
}
}
