package com.ge.training.threads;

class First implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=1;i<=100;i++) {
			System.out.println("inside first thread "+i);
		}
	}
	
}

class Second implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=1;i<=100;i++) {
			System.out.println("inside second thread "+i);
		}
	}
	
}
public class ThreadTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		First f=new First();
		Second s=new Second();
		Thread t1=new Thread(f);
		Thread t2=new Thread(s);
		t1.start();
		t2.start();
		for(int i=1;i<=100;i++) {
			System.out.println("inside main thread "+i);
		}
	}

}
