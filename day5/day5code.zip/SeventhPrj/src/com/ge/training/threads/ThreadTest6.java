package com.ge.training.threads;

class Y implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		display();
	}
	public void display()
	{
		synchronized(this) { //beginning of synchronized block
		System.out.println("--A--");
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("--B--");
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}//end of synchronized block
		System.out.println("--C--");
		
	}
}

public class ThreadTest6 {
	public static void main(String[] args) {
		Y y=new Y();
		Thread t1=new Thread(y);
		Thread t2=new Thread(y);
		t1.setName("First Thread");
		t2.setName("Second Thread");
		t1.start();
		t2.start();
	}

}
