package com.ge.training.threads;

class FirstThread extends Thread{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=1;i<=100;i++) {
			System.out.println("inside first thread "+i);
		}
	}
	
}

class SecondThread extends Thread{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=1;i<=100;i++) {
			System.out.println("inside second thread "+i);
			if(i>60) {
				try {
				throw new ArithmeticException();
				}catch(Exception e) {
					return;
				}
			}
		}
	}
	
}
public class ThreadTest2 {
public static void main(String[] args) {
	FirstThread f=new FirstThread();
	SecondThread s=new SecondThread();
	f.start();
	s.start();
}
}
