package com.ge.training.threads;

class X implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		display();
	}
	synchronized public void display()
	{
		System.out.println("--A--");
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("--B--");
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("--C--");
		
	}
}

public class ThreadTest5 {
	public static void main(String[] args) {
		X x=new X();
		Thread t1=new Thread(x);
		Thread t2=new Thread(x);
		t1.setName("First Thread");
		t2.setName("Second Thread");
		t1.start();
		t2.start();
	}

}
