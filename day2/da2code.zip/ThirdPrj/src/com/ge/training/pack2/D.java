package com.ge.training.pack2;

import com.ge.training.pack1.A;

public class D  extends A{
	void print()
	{
		System.out.println(i);
	}
}
