package com.ge.training.pack2;

import com.ge.training.pack1.A;

public class C {
	void print()
	{
		A a=new A();
		System.out.println(a.i); 
	}

}
