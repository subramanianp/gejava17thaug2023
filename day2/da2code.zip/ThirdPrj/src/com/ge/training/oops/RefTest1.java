package com.ge.training.oops;

public class RefTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A a1=new A(10);
		A a2=a1;//both the reference variables point to the same object.
		a1.increment();
		a1.print();//prints 11
		a2.print();//prints 11

		a2.increment();
		a1.print();//prints 12
		a2.print();//prints 12
		a1=new A(20);//a1 now points to the object with value 20 but a2 still points to object with
		//value 12	
		a1.print();//prints 20
		a2.print();//prints 12
		a2=null;//a2 does not point to any object.
		a1=new A(30);
		System.gc();//not enforcing gc but a suggestion.
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}

}
