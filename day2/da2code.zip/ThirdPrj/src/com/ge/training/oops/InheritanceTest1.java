package com.ge.training.oops;

public class InheritanceTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Person p1=new Person("Arvind", 21, new Address(1214, "G-10th Street", "Hebbal", "Bangalore"));
		p1.print();
		Address a1=new Address(4422,"Nethaji road","Bandra East","Mumbai");
		Employee e1=new Employee("Surya", 35, 
				a1, 1001, 40000);
		e1.print();

	}

}
