package com.ge.training.oops;

class A{
	private int i;
	A(int i)
	{
		this.i=i;
	}
	void print() {
		System.out.println("A[i="+i+"]");
	}
	void increment() {
		i++;
	}
	public void finalize()
	{
		System.out.println("Garbage collecting the object with value "+i);
	}
}

class Sample{
	void change(int i) {
		i++;
	}
	void change(A a) {
		a.increment();
	}
}

public class PassingValues {
public static void main(String[] args) {
	Sample sample=new Sample();
	A a=new A(10);
	int x=20;
	a.print();
	System.out.println(x);
	sample.change(x);
	sample.change(a);
	a.print();
	System.out.println(x);
}
}
