package com.ge.training.oops;
class X{
	int i=10;
}

class Y extends X{
	private int i=20;
	void print()
	{
		int i=30;
		System.out.println("i="+i);
		System.out.println("i="+this.i);
		System.out.println("i="+super.i);
	}
}
public class InheritanceTest2 {
	public static void main(String[] args) {
		Y y1=new Y();
		y1.print();
	}

}
