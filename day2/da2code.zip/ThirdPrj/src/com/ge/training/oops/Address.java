package com.ge.training.oops;

public class Address {
	private int plotNumber;
	private String street;
	private String location;
	private String city;
	public Address(int plotNumber, String street, String location, String city) {
		super();
		this.plotNumber = plotNumber;
		this.street = street;
		this.location = location;
		this.city = city;
	}
	
	public void print() {
		System.out.println(plotNumber+","+street);
		System.out.println("location: "+location);
		System.out.println("city:"+city);
	}
	
	

}
