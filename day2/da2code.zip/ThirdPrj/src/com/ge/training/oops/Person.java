package com.ge.training.oops;

public class Person {
	private String name;
	private int age;
	private Address address;//composition
	public Person(String name, int age, Address address) {
		super();
		this.name = name;
		this.age = age;
		this.address = address;
	}
	
	
	public void print()
	{
		System.out.println("Name:"+name);
		System.out.println("Age:"+age);
		System.out.println("Address");
		address.print();
	}
}
