package com.ge.training.oops;

class P{
	
	  public String toString() {
		  return "Object of type P"; 
		 }
	 
}

class R{
	private int i;
	private int j;
	public R(int i, int j) {
		super();
		this.i = i;
		this.j = j;
	}
	
	public String toString() {
		return "R [i=" + i + ", j=" + j + "]";
	}
	
	
	
	
}
public class ToStringTest {
public static void main(String[] args) {
	P p=new P();
	System.out.println(p);
	R r=new R(10,20);
	System.out.println(r);
}
}
