package com.ge.training.oops;

public class Employee extends Person{
	private int empId;
	private double salary;
	public Employee(String name, int age, Address address, int empId, double salary) {
		super(name, age, address); //invokes the super class constructor which takes name,age and 
		//address as parameters
		this.empId = empId;
		this.salary = salary;
	}
	
	public void print() {
		super.print();
		System.out.println("Employee Id:"+empId);
		System.out.println("Salary:"+salary);
	}
	
	
}
