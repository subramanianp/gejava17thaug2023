package com.ge.training.pack1;

public class A {
	public int i=10;
}

class B{
	void print()
	{
		A a1=new A();
		System.out.println(a1.i); //not allowed because 
		//i is private
	}
}