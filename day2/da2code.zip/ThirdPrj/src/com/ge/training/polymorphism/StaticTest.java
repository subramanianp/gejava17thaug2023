package com.ge.training.polymorphism;
class A{
	static int i;
	
	static void test() {
		System.out.println("static method of A");
	}
}



public class StaticTest {
public static void main(String[] args) {
	A a1=new A();
	A a2=new A();
	A a3=new A();
	a1.i=10;
	a2.i=20;
	a3.i=30;
	System.out.println(a1.i+a2.i+a3.i);
	System.out.println(A.i);
	A.test();
}
}
