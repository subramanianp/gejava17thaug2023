package com.ge.training.polymorphism;

class Person{
	private String name;
	
	public Person(String name) {
		super();
		this.name = name;
	}

	void test()
	{
		System.out.println("testing person");
	}
}

class Employee extends Person{
	private int empId;
	private double salary;

	public Employee(String name, int empId, double salary) {
		super(name);
		this.empId = empId;
		this.salary = salary;
	}

	@Override
	void test() {
		// TODO Auto-generated method stub
		System.out.println("testing employee");
	}
		/*void test()
		{
			System.out.println("testing employee");
		}*/
	
	public double getSalary() {
		return salary;
	}
}

class Manager extends Employee{
	private String location;
	
	
	public Manager(String name, int empId, double salary, String location) {
		super(name, empId, salary);
		this.location = location;
	}


	void test()
	{
		System.out.println("testing manager");
	}
}

class Utility{
	void process(Person p)
	{
		p.test();
		//remaining logic
	}
	double calculateBonus(Employee e)
	{
		double bonus=0;
		if(e instanceof Manager) {
			bonus=0.40*e.getSalary();
		}
		else  if(e instanceof Employee) {
			bonus=0.30*e.getSalary();
		}
		
		 
		return bonus;
	}
}

public class PoymorphismTest1 {
public static void main(String[] args) {
/*	Employee e=new Employee();
	Person p=new Person();
	Manager m=new Manager();
	Utility u=new Utility();
	u.process(p);
	u.process(e);
	u.process(m);*/
	Employee e1=new Employee("Arvind", 1001, 50000);
	Manager m1=new Manager("Suresh", 1002, 80000, "Karnataka");
	Utility u=new Utility();
	System.out.println("Bonus for employee e1:"+u.calculateBonus(e1));
	System.out.println("Bonus for manager m1:"+u.calculateBonus(m1));

}
}
