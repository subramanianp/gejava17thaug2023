package com.ge.training.polymorphism;
abstract class Animal{
	abstract String color();
	abstract int lifeCycleTime();
	
	void describe() {
		System.out.println("Color: "+color());
		System.out.println("Life Cycle Time: "+lifeCycleTime()+" years");
	}
}

class Rabbit extends Animal{

	@Override
	String color() {
		// TODO Auto-generated method stub
		return "White";
	}

	@Override
	int lifeCycleTime() {
		// TODO Auto-generated method stub
		return 10;
	}
	
}

class Elephant extends Animal{

	@Override
	String color() {
		// TODO Auto-generated method stub
		return "Black";
	}

	@Override
	int lifeCycleTime() {
		// TODO Auto-generated method stub
		return 40;
	}
	
}

public class AbstractTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Animal a=new Rabbit();
		a.describe();
		a=new Elephant();
		a.describe();
	}

}
