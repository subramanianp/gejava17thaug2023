package com.ge.training.polymorphism;


class X{
	int i;
	static int j;
	static void test()
	{
	System.out.println("static method of X");
	//System.out.println(i);//error
	//System.out.println(this.j);
	}
}

class Y extends X{
	
	static void test()
	{
	System.out.println("static method of Y");
	
	}
}

public class StaticTest2 {
public static void main(String[] args) {
	X x=new Y();
	x.test();
}
}
