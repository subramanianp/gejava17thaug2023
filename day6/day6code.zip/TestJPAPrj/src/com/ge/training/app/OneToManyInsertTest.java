package com.ge.training.app;

import java.util.Arrays;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.ge.training.domain.Address;
import com.ge.training.domain.Customer;
import com.ge.training.domain.Employee;

public class OneToManyInsertTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EntityManagerFactory factory=Persistence.createEntityManagerFactory("test-unit");
		EntityManager em=factory.createEntityManager();
		Employee e1=new Employee(1001, "Surya", "Developer");
		Employee e2=new Employee(1002, "Amar", "Accountant");
		Address address11=new Address(501, "Ulsoor", "Bangalore");
		Address address12=new Address(502, "Hinjewadi", "Pune");
		
		Address address21=new Address(503, "Punjakutta", "Hyderabad");
		Address address22=new Address(504, "Mambalam", "Chennai");
		
		e1.setAddresses(Arrays.asList(address11,address12));
		e2.setAddresses(Arrays.asList(address21,address22));
		
		EntityTransaction tx= em.getTransaction();
		tx.begin();
		em.persist(e1);
		em.persist(e2);
		tx.commit();
		em.close();
		factory.close();
		
	}

}
