package com.ge.training.app;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.ge.training.domain.Customer;

public class JPATest2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EntityManagerFactory factory=Persistence.createEntityManagerFactory("test-unit");
		EntityManager em=factory.createEntityManager();
		String jpaQL="select c from Customer c";
		Query query=em.createQuery(jpaQL);
		List<Customer> customers= query.getResultList();
		for(Customer customer:customers) {
			System.out.println(customer.getCustId()+"\t"+customer.getName()+"\t"+customer.getEmail());
		}
		em.close();
		factory.close();
		
	}

}
