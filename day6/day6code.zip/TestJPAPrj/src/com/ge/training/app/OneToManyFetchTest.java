package com.ge.training.app;

import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.ge.training.domain.Address;
import com.ge.training.domain.Customer;
import com.ge.training.domain.Employee;

public class OneToManyFetchTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EntityManagerFactory factory=Persistence.createEntityManagerFactory("test-unit");
		EntityManager em=factory.createEntityManager();
		
		
		String jpaQL="select e from Employee e";
		Query query=em.createQuery(jpaQL);
		List<Employee> employees=query.getResultList();
		for(Employee e:employees) {
			System.out.println(e.getEmpId()+"\t"+e.getEmpName()+"\t"+e.getDesignation());
			System.out.println("Addresses of this employee");
			List<Address> addresses=e.getAddresses();
			for(Address address:addresses) {
				System.out.println(address.getAddressId()+"\t"+address.getLocation()
				+"\t"+address.getCity());
			}
		}
		em.close();
		factory.close();
		
	}

}
