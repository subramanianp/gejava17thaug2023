package com.ge.training.app;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.ge.training.domain.Customer;

public class JPATest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EntityManagerFactory factory=Persistence.createEntityManagerFactory("test-unit");
		EntityManager em=factory.createEntityManager();
		Customer c1=new Customer(4001, "Rajiv", "rajiv@gmail.com");
		Customer c2=new Customer(4002, "Akash", "akash@yahoo.com");
		EntityTransaction tx= em.getTransaction();
		tx.begin();
		em.persist(c1);
		em.persist(c2);
		tx.commit();
		em.close();
		factory.close();
		
	}

}
