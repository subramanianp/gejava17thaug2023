package com.ge.training.threads;

class X{
	
}
class Y{
	
}

class FirstThread extends Thread{
	private X x;
	private Y y;
	public FirstThread(X x, Y y) {
		super();
		this.x = x;
		this.y = y;
	}
	public void run()
	{
		System.out.println("First thread is going to acquire lock on x");
		synchronized (x) {
			System.out.println("First thread has acquired lock on x");
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("First thread is trying to acquire lock on y");
			synchronized (y) {
				System.out.println("First thread has acquired lock on y");
			}
		}
	}
	
}

class SecondThread extends Thread{
	private X x;
	private Y y;
	public SecondThread(X x, Y y) {
		super();
		this.x = x;
		this.y = y;
	}
	public void run()
	{
		System.out.println("Second thread is going to acquire lock on y");
		synchronized (y) {
			System.out.println("Second thread has acquired lock on y");
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Second thread is trying to acquire lock on x");
			synchronized (x) {
				System.out.println("Second thread has acquired lock on x");
			}
		}
	}
	
}

public class DeadLockTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		X x1=new X();
		Y y1=new Y();
		FirstThread ft=new FirstThread(x1, y1);
		SecondThread st=new SecondThread(x1, y1);
		ft.setName("First-Thread");
		st.setName("Second-Thread");
		ft.start();
		st.start();

	}

}
