package com.ge.training.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcTest3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection con=null;
		try {
			String username=System.getProperty("user");
			String password=System.getProperty("password");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/trainingdb",
					username,password);
			
			String sql="insert into employee values(?,?,?)";
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setInt(1, Integer.parseInt(args[0]));
			pst.setString(2, args[1]);
			pst.setString(3, args[2]);
			int count=pst.executeUpdate();
			if(count>0) {
				System.out.println("row successfully inserted");
			}
			else {
				System.out.println("error in inserting");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

	}

}
