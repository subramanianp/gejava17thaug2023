package com.ge.training.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ge.training.beans.Customer;

public class DITest1 {
public static void main(String[] args) {
	ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
	Customer customer=(Customer)context.getBean("cust");
	System.out.println(customer.getId()+"\t"+customer.getName());
}
}
