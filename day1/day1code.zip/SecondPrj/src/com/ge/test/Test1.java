package com.ge.test;

import com.ge.first.Sample;
import com.ge.third.Next;

import pack1.Fifth;
import pack1.Fourth;

public class Test1 {

	public static void main(String[] args) {
		Sample s=new Sample();
		Next n=new Next();
		s.print();
		n.test();
		Fourth fourth=new Fourth();
		Fifth fifth=new Fifth();
		fourth.print();
		fifth.print();
	}
}
