package com.ge.second;

import com.ge.first.Sample;

public class SampleTest {
	public static void main(String[] args) {
		Sample sample=new Sample();
		sample.print();
	}
}
