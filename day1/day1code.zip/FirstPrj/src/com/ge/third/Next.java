package com.ge.third;

public class Next {
	public void test() {
	
		System.out.println("test method of Next unxer com.ge.third");
	}
}
