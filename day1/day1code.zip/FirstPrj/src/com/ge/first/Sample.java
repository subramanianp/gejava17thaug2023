package com.ge.first;

public class Sample {
	public void print()
	{
		System.out.println("print method of Sample under package com.ge.first");
	}
}
