package com.ge.web.controller;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ge.web.domain.Employee;

@RequestMapping("/emp")
@RestController
public class EmployeeController {
	@GetMapping(path = "/data",produces = MediaType.APPLICATION_JSON_VALUE)
	public Employee getData() {
		return new Employee(1002, "Amar", "Developer");
	}

}
