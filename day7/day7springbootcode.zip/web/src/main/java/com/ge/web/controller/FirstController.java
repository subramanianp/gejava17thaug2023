package com.ge.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/first")
public class FirstController {
	@RequestMapping("/message") // /first/message
	public @ResponseBody String getData()
	{
		return "<html><body><h2>Welcome to Spring Boot</h2></body></html>";
	}
	@RequestMapping("/next") // /first/next
	public @ResponseBody String getNextData()
	{
		return "<html><body><h2>This is another message from spring boot</h2></body></html>";
	}

}
