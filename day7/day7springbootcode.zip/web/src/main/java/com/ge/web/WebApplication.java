package com.ge.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.ge.web.domain.Employee;

@SpringBootApplication
public class WebApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebApplication.class, args);
	}

	
	@Bean
	public Employee getEmployee()
	{
		return new Employee(1001, "Arvind", "Developer");
	}
}
