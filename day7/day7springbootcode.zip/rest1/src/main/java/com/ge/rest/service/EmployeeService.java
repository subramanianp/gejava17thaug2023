package com.ge.rest.service;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

import org.springframework.stereotype.Service;

import com.ge.rest.domain.Employee;

@Service
public class EmployeeService {
	private TreeMap<Integer, Employee> empData=new TreeMap<>();
	
	public EmployeeService() {
		empData.put(1001, new Employee(1001, "Arjun", "Accountant"));
		empData.put(1002, new Employee(1002, "Surya", "Developer"));
		empData.put(1003, new Employee(1003, "Rajiv", "Accountant"));
		empData.put(1004, new Employee(1004, "Deva", "Architect"));
	}
	
	public Employee getEmployeeDetails(int id)
	{
		return empData.get(id);
	}
	
	public List<Employee> getAllEmployees()
	{
		return new ArrayList<>(empData.values());
	}
	
	public String addEmployee(Employee e)
	{
		int nextId=empData.lastKey()+1;
		e.setId(nextId);
		empData.put(nextId, e);
		return "Employee with id "+nextId+" added successfully";
	}
	public String updateEmployee(int id,Employee e)
	{
		Employee e1=empData.get(id);
		e1.setName(e.getName());
		e1.setDesignation(e.getDesignation());
		
		return "Employee with id "+id+" updated successfully";
	}
	
	public String removeEmployee(int id)
	{
		empData.remove(id);
		
		return "Employee with id "+id+" removed successfully";
	}
	
}
