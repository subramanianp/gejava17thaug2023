package com.ge.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ge.rest.domain.Employee;
import com.ge.rest.service.EmployeeService;

@RestController
@RequestMapping("/emp")
public class EmployeeController {
	@Autowired
	private EmployeeService service;
	
	@GetMapping(path = "/{id}", produces = {MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE
	})
	public ResponseEntity<Employee> getEmployee(@PathVariable("id") int empId)
	{
		Employee employee= service.getEmployeeDetails(empId);
		
		return new ResponseEntity<>(employee,HttpStatus.OK);
	}

	@GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Employee>> getAllEmployees()
	{
		List<Employee> employees= service.getAllEmployees();
		
		return new ResponseEntity<>(employees,HttpStatus.OK);
	}
	
	@PostMapping(consumes = {MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE
	},produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity<String>  addEmployee(@RequestBody Employee e)
	{
		String responseMsg=service.addEmployee(e);
		return new ResponseEntity<>(responseMsg,HttpStatus.CREATED);
	}
	@PutMapping(path="/{id}",consumes = {MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE
	},produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity<String>  updateEmployee(@PathVariable("id")int empId, @RequestBody Employee e)
	{
		String responseMsg=service.updateEmployee(empId, e);
		return new ResponseEntity<>(responseMsg,HttpStatus.OK);
	}
	@DeleteMapping(path="/{id}",produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity<String>  removeEmployee(@PathVariable("id")int empId)
	{
		String responseMsg=service.removeEmployee(empId);
		return new ResponseEntity<>(responseMsg,HttpStatus.OK);
	}
	
}
