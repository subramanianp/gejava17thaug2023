package com.ge.training.app;

import java.util.List;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ge.training.beans.collections.Address;
import com.ge.training.beans.collections.Customer;



public class DITest2 {
public static void main(String[] args) {
	AbstractApplicationContext context=new ClassPathXmlApplicationContext("beans-collection.xml");
	Customer customer=(Customer)context.getBean("cust");
	System.out.println(customer.getId()+"\t"+customer.getName());
	List<Address> addresses=customer.getAddresses();
	for(Address address:addresses) {
		System.out.println(address.getLocation()+"\t"+address.getCity());
	}
	
	
	context.close();
}
}
