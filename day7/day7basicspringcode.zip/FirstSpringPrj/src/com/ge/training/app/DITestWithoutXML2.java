package com.ge.training.app;



import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.ge.training.beans.annotations.A;
import com.ge.training.beans.annotations.B;
import com.ge.training.config.BeanConfig;




public class DITestWithoutXML2 {
public static void main(String[] args) {
	AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext(BeanConfig.class);;
	
	A a=context.getBean(A.class);
	System.out.println(a.getMsg());
	B b=a.getB();
	System.out.println(b.getI());
	context.close();
}
}
