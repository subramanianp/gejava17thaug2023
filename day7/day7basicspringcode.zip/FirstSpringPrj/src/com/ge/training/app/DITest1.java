package com.ge.training.app;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ge.training.beans.Address;
import com.ge.training.beans.Customer;

public class DITest1 {
public static void main(String[] args) {
	AbstractApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
	Customer customer=(Customer)context.getBean("cust");
	System.out.println(customer.getId()+"\t"+customer.getName());
	Address address=customer.getAddress();
	System.out.println("Location:"+address.getLocation());
	System.out.println("City:"+address.getCity());
	context.close();
}
}
