package com.ge.training.app;

import java.util.List;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ge.training.beans.annotations.Address;
import com.ge.training.beans.annotations.Customer;




public class DITest3 {
public static void main(String[] args) {
	AbstractApplicationContext context=new ClassPathXmlApplicationContext("beans-components.xml");
	Customer customer=(Customer)context.getBean(Customer.class);
	//Customer customer=(Customer)context.getBean("cust);
	System.out.println(customer.getId()+"\t"+customer.getName());
	Address address=customer.getAddress();
	System.out.println("Location: "+address.getLocation());
	System.out.println("City: "+address.getCity());
	
	
	context.close();
}
}
