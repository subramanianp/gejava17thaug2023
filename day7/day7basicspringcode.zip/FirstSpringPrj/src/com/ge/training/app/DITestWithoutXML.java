package com.ge.training.app;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ge.training.beans.annotations.A;
import com.ge.training.beans.annotations.Address;
import com.ge.training.beans.annotations.B;
import com.ge.training.beans.annotations.Customer;
import com.ge.training.config.BeanConfig;




public class DITestWithoutXML {
public static void main(String[] args) {
	AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext(BeanConfig.class);;
	/*Customer customer=(Customer)context.getBean("cust");
	
	System.out.println(customer.getId()+"\t"+customer.getName());
	Address address=customer.getAddress();
	
	System.out.println(address.getLocation()+"\t"+address.getCity());
	*/
	A a=context.getBean(A.class);
	B b=context.getBean(B.class);
	System.out.println(a.getMsg());
	System.out.println(b.getI());
	context.close();
}
}
