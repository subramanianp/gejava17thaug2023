package com.ge.training.beans.annotations;

import org.springframework.beans.factory.annotation.Autowired;

public class A {
private String msg="hello";

@Autowired
private B b;



public B getB() {
	return b;
}

public void setB(B b) {
	this.b = b;
}

public String getMsg() {
	return msg;
}

public void setMsg(String msg) {
	this.msg = msg;
}

}
