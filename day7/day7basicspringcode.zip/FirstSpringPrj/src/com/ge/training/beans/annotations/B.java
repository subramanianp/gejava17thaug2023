package com.ge.training.beans.annotations;

public class B {
	private int i=10;

	public int getI() {
		return i;
	}

	public void setI(int i) {
		this.i = i;
	}
	
}
