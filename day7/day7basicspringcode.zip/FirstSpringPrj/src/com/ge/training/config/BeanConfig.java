package com.ge.training.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.ge.training.beans.annotations.A;
import com.ge.training.beans.annotations.B;

@Configuration
@ComponentScan(basePackages = {"com.ge.training.beans.annotations"})
public class BeanConfig {
	
	@Bean
	public A getA() {
		return new A();
	}
	@Bean
	public B getB()
	{
		return new B();
	}
	

}
