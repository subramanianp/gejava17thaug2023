package com.boa.training.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.boa.training.domain.Item;

@Service
public class ItemService {
	private Map<Integer, Item> itemData=new HashMap<>();
	
	public ItemService()
	{
		itemData.put(101, new Item(101, "Apple", 200));
		itemData.put(102, new Item(102, "Orange", 100));
		itemData.put(103, new Item(103, "Mango", 150));
		
		
	}
	
	public Item getItemDetails(int id)
	{
		return itemData.get(id);
	}

}
