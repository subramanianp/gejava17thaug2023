package com.ge.restwithjpa.domain;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Response {
		private String message;
		
		public String getMessage() {
			return message;
		}
		public void setMessage(String message) {
			this.message = message;
		}
		public Response() {
			super();
			// TODO Auto-generated constructor stub
		}
		public Response(String message) {
			super();
			this.message = message;
		}
		
		

}
