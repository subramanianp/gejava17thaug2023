package com.ge.training.restclients;

import java.util.Arrays;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.ge.restwithjpa.domain.Employee;
import com.ge.restwithjpa.domain.Employees;

public class GetEmpListClient {
public static void main(String[] args) {
	RestTemplate template=new RestTemplate();
	String url="http://localhost:8080/emp";
	HttpHeaders headers=new HttpHeaders();
	headers.put("Accept", Arrays.asList(MediaType.APPLICATION_JSON_VALUE));
	HttpEntity<String> entity=new HttpEntity<>(headers);
	//sends the actual request
	ResponseEntity<Employees> responseEntity=template.exchange(url, HttpMethod.GET,entity,
			Employees.class);
	Employees employees=responseEntity.getBody();
	for(Employee employee:employees.getEmployee()) {
		System.out.println(employee.getId()+"\t"+employee.getName()+
				"\t"+employee.getDesignation());
	}
}
}
