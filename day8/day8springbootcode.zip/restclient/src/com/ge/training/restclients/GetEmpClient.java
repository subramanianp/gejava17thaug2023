package com.ge.training.restclients;

import java.util.Arrays;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.ge.restwithjpa.domain.Employee;

public class GetEmpClient {
public static void main(String[] args) {
	RestTemplate template=new RestTemplate();
	String url="http://localhost:8080/emp/1";
	HttpHeaders headers=new HttpHeaders();
	headers.put("Accept", Arrays.asList(MediaType.APPLICATION_JSON_VALUE));
	HttpEntity<String> entity=new HttpEntity<>(headers);
	//sends the actual request
	ResponseEntity<Employee> responseEntity=template.exchange(url, HttpMethod.GET,entity,
			Employee.class);
	Employee employee=responseEntity.getBody();
	System.out.println("Name:"+employee.getName());
	System.out.println("Designation:"+employee.getDesignation());
	
}
}
