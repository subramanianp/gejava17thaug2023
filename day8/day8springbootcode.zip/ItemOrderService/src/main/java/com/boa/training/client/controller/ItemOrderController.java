package com.boa.training.client.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boa.training.client.domain.ItemOrder;
import com.boa.training.client.service.ItemOrderService;

@RestController
@RequestMapping("/itemorder")
public class ItemOrderController {
	
	@Autowired
	private ItemOrderService service;
	
	@GetMapping(path="/{code}/qty/{quantity}",produces =MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ItemOrder> placeOrder(@PathVariable("code")int code,@PathVariable("quantity")int quantity)
	{
		ItemOrder order=service.placeOrder(code, quantity);
		return new ResponseEntity<ItemOrder>(order, HttpStatus.OK);
	}

	@GetMapping(path="/proxy/{code}/qty/{quantity}",produces =MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ItemOrder> placeOrderThroughProxy(@PathVariable("code")int code,@PathVariable("quantity")int quantity)
	{
		ItemOrder order=service.placeOrderThroughProxy(code, quantity);
		return new ResponseEntity<ItemOrder>(order, HttpStatus.OK);
	}
	
}
