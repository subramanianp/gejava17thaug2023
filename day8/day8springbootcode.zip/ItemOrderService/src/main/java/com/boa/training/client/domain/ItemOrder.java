package com.boa.training.client.domain;

public class ItemOrder {
	private int itemCode;
	private String itemName;
	private double totalAmount;
	private int quantity;
	public int getItemCode() {
		return itemCode;
	}
	public void setItemCode(int itemCode) {
		this.itemCode = itemCode;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public ItemOrder(int itemCode, String itemName, double totalAmount) {
		super();
		this.itemCode = itemCode;
		this.itemName = itemName;
		this.totalAmount = totalAmount;
	}
	public ItemOrder() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	
	
	
}
