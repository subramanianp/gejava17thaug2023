package com.boa.training.client.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.boa.training.client.domain.Item;

//Proxy of Item Micro Service
@Component
@FeignClient("ITEMMICROSERVICE")
public interface ItemProxy {
	@GetMapping("/item/{code}")
	public Item getItem(@PathVariable("code") int itemCode);

}
