package com.boa.training.client.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.boa.training.client.domain.Item;
import com.boa.training.client.domain.ItemOrder;
import com.boa.training.client.proxy.ItemProxy;

@Service
public class ItemOrderService {
	@Autowired
	private RestTemplate template;
	
	@Autowired
	private ItemProxy proxy;
	
	public ItemOrder placeOrder(int code,int quantity)
	{
		Item item=template.getForObject("http://localhost:8001/item/"+code,Item.class);
		double totalAmount=item.getPrice()*quantity;
		ItemOrder order=new ItemOrder(code, item.getItemName(), totalAmount);
		order.setQuantity(quantity);
		return order;
	}
	
	public ItemOrder placeOrderThroughProxy(int code,int quantity)
	{
		Item item=proxy.getItem(code);
		double totalAmount=item.getPrice()*quantity;
		ItemOrder order=new ItemOrder(code, item.getItemName(), totalAmount);
		order.setQuantity(quantity);
		return order;
	}
	

}
