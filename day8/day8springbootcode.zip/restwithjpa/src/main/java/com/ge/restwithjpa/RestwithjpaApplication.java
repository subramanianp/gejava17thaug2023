package com.ge.restwithjpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestwithjpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestwithjpaApplication.class, args);
	}

}
