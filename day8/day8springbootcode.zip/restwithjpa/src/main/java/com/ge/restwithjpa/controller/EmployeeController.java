package com.ge.restwithjpa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ge.restwithjpa.domain.Employee;
import com.ge.restwithjpa.domain.Employees;
import com.ge.restwithjpa.domain.Response;
import com.ge.restwithjpa.service.EmployeeService;



@RestController
@RequestMapping("/emp")
public class EmployeeController {
	@Autowired
	private EmployeeService service;
	
	@GetMapping(path = "/{id}", produces = {MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE
	})
	public ResponseEntity<?> getEmployee(@PathVariable("id") int empId)
	{
		Employee employee= service.getEmployeeDetails(empId);
		if(employee==null) {
			Response response= new Response("No employee with id "+empId);
			return new ResponseEntity<Response>(response,HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(employee,HttpStatus.OK);
	}

	@GetMapping(produces = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public ResponseEntity<Employees> getAllEmployees()
	{
		List<Employee> employees= service.getAllEmployees();
		
		return new ResponseEntity<>(new Employees(employees) ,HttpStatus.OK);
	}
	
	@PostMapping(consumes = {MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE
	},produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity<String>  addEmployee(@RequestBody Employee e)
	{
		String responseMsg=service.addEmployee(e);
		return new ResponseEntity<>(responseMsg,HttpStatus.CREATED);
	}
	@PutMapping(path="/{id}",consumes = {MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE
	},produces = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public ResponseEntity<?>  updateEmployee(@PathVariable("id")int empId, @RequestBody Employee e)
	{
		int id=service.updateEmployee(empId, e);
		if(id==-1) {
			Response response= new Response("No employee with id "+empId);
			return new ResponseEntity<Response>(response,HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(new Response("Employee with id "+empId+" updated successfully"),
				HttpStatus.OK);
	}
	@DeleteMapping(path="/{id}",produces = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public ResponseEntity<?>  removeEmployee(@PathVariable("id")int empId)
	{
		int id=service.removeEmployee(empId);
		if(id==-1) {
			Response response= new Response("No employee with id "+empId);
			return new ResponseEntity<Response>(response,HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(new Response("Employee with id "+empId+" removed successfully"),
				HttpStatus.OK);
	}
	
}
