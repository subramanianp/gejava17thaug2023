package com.ge.restwithjpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ge.restwithjpa.entity.EmployeeDTO;
//EmployeeDTO is the entity
//Integer is the primary key type
@Repository
public interface EmployeeRepository extends JpaRepository<EmployeeDTO, Integer>{

}
