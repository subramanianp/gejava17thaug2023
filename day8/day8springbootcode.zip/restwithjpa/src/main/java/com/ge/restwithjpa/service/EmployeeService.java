package com.ge.restwithjpa.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.restwithjpa.domain.Employee;
import com.ge.restwithjpa.entity.EmployeeDTO;
import com.ge.restwithjpa.repository.EmployeeRepository;



@Service
public class EmployeeService {
	@Autowired
	private EmployeeRepository repository;
	
	public Employee getEmployeeDetails(int id)
	{
		Optional<EmployeeDTO> opt=repository.findById(id);
		if(opt.isPresent()) {
			EmployeeDTO dto=opt.get();
			return new Employee(dto);
		}
		return null;
	}
	
	public List<Employee> getAllEmployees()
	{
		List<EmployeeDTO> dtoList=repository.findAll();
		List<Employee> employees=new ArrayList<>();
		for(EmployeeDTO dto:dtoList) {
			employees.add(new Employee(dto));
		}
		return employees;
	}
	
	public String addEmployee(Employee e)
	{
		
		EmployeeDTO dto=repository.saveAndFlush(new EmployeeDTO(e)); //inserts the row and flushes the data and
		//returns the entity which is inserted along with generated id
		
		return "Employee with id "+dto.getEmpId()+" added successfully";
	}
	public int updateEmployee(int id,Employee e)
	{
		Optional<EmployeeDTO> opt=repository.findById(id);
		if(opt.isPresent()) {
			EmployeeDTO e1=opt.get();
			e1.setEmpName(e.getName());
			e1.setDesignation(e.getDesignation());
			repository.save(e1);
			return id;
		}
		return -1;
	}
	
	public int removeEmployee(int id)
	{
		Optional<EmployeeDTO> opt=repository.findById(id);
		if(opt.isPresent()) {
			repository.delete(opt.get());
			return id;
		}
		return -1;

		
	}
	
}
